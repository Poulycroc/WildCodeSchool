const env = {
    DATABASE_HOST: "hostname",
    DATABASE_USER: "user",
    DATABASE_PASSWORD: "password",
    DATABASE_NAME: 'db_name'
}

module.exports = env;
