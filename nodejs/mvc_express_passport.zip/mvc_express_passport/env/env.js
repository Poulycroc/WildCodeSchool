
const env = {
    DATABASE_HOST: "localhost",
    DATABASE_USER: "root",
    DATABASE_PASSWORD: "root",
    DATABASE_NAME: 'shopping',
    DATABASE_PORT: 8889

}

module.exports = env;
